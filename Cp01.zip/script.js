alert('bem vindo a pagina principal')
function trocar(cor){
    document.body.style.background =cor
    
}
